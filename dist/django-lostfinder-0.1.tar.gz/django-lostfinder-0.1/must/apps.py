from django.apps import AppConfig


class MustConfig(AppConfig):
    name = 'must'
